package app.com.nishswag.android.lawyers1002;

/**
 * Created by Nishant Koli on 28.03.15.
 */
public class Cases {

    private String _casenumber, _startdate, _enddate, _petitioners,_respondants,_courtname,_courtstate,_casenotes;
    private int _id2;

    public Cases (int id2, String caseno, String startdate, String enddate, String petitioners, String respondants, String courtname, String courtstate, String casenotes ) {
        _id2 = id2;
        _casenumber = caseno;
        _startdate = startdate;
        _enddate = enddate;
        _petitioners = petitioners;
        _respondants = respondants;
        _courtname = courtname;
        _courtstate = courtstate;
        _casenotes = casenotes;

    }

    public int getId() { return _id2; }

    public String getCaseNumber() {
        return _casenumber;
    }

    public String getStartDate() {
        return _startdate;
    }

    public String getEndDate() {
        return _enddate;
    }

    public String getPetitioners() {
        return _petitioners;
    }

    public String getRespondants() { return _respondants; }

    public String getCourtName() { return _courtname; }

    public String getCourtState() { return _courtstate; }

    public String getCaseNotes() { return  _casenotes; }
}
