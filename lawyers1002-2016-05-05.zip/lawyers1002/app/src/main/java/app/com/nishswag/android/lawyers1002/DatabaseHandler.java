package app.com.nishswag.android.lawyers1002;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nishant Koli on 19.01.15.
 */
public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "lawyourDB",
            TABLE_CONTACTS = "contacts",
            KEY_ID = "id",
            KEY_NAME = "name",
            KEY_PHONE = "phone",
            KEY_EMAIL = "email",
            KEY_ADDRESS = "address",
            KEY_IMAGEURI = "imageUri";

    private static final String TABLE_CASES = "cases",
            KEY_ID2 = "id2",
            KEY_CASENO = "casenumber",
            KEY_STARTDATE = "startdate",
            KEY_ENDDATE = "enddate",
            KEY_CASEPETI = "petitioners",
            KEY_CASERESP = "respondants",
            KEY_COURTNAME = "courtname",
            KEY_COURTSTATE = "courtstate",
            KEY_CASENOTES = "casenotes";



    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_CONTACTS + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_NAME + " TEXT," + KEY_PHONE + " TEXT," + KEY_EMAIL + " TEXT," + KEY_ADDRESS + " TEXT," + KEY_IMAGEURI + " TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_CASES + "(" + KEY_ID2 + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_CASENO + " TEXT," + KEY_STARTDATE + " TEXT," + KEY_ENDDATE + " TEXT," + KEY_CASEPETI + " TEXT," + KEY_CASERESP + " TEXT," + KEY_COURTNAME + " TEXT," + KEY_COURTSTATE + " TEXT," + KEY_CASENOTES + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CASES);

        onCreate(db);
    }

    public void createContact(app.com.nishswag.android.lawyers1002.Contact contact) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PHONE, contact.getPhone());
        values.put(KEY_EMAIL, contact.getEmail());
        values.put(KEY_ADDRESS, contact.getAddress());
        values.put(KEY_IMAGEURI, contact.getImageURI().toString());

        db.insert(TABLE_CONTACTS, null, values);
        db.close();
    }

    public void createCases(app.com.nishswag.android.lawyers1002.Cases cases) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_CASENO, cases.getCaseNumber());
        values.put(KEY_STARTDATE, cases.getStartDate());
        values.put(KEY_ENDDATE, cases.getEndDate());
        values.put(KEY_CASEPETI, cases.getPetitioners());
        values.put(KEY_CASERESP, cases.getRespondants());
        values.put(KEY_COURTNAME, cases.getCourtName());
        values.put(KEY_COURTSTATE, cases.getCourtState());
        values.put(KEY_CASENOTES, cases.getCaseNotes());

        db.insert(TABLE_CASES, null, values);
        db.close();


    }

    public app.com.nishswag.android.lawyers1002.Contact getContact(int id) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(TABLE_CONTACTS, new String[] { KEY_ID, KEY_NAME, KEY_PHONE, KEY_EMAIL, KEY_ADDRESS, KEY_IMAGEURI }, KEY_ID + "=?", new String[] { String.valueOf(id) }, null, null, null, null );

        if (cursor != null)
            cursor.moveToFirst();

        app.com.nishswag.android.lawyers1002.Contact contact = new app.com.nishswag.android.lawyers1002.Contact(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), Uri.parse(cursor.getString(5)));
        db.close();
        cursor.close();
        return contact;
    }

    public void deleteContact(Contact contact) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_CONTACTS, KEY_ID + "=?", new String[]{String.valueOf(contact.getId())});
        db.close();
    }

    public void deleteCases(Cases cases) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_CASES, KEY_ID + "=?", new String[]{String.valueOf(cases.getId())});
        db.close();
    }

    public int getContactsCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CONTACTS, null);
        int count = cursor.getCount();
        db.close();
        cursor.close();

        return count;
    }

    public int getCasesCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CASES, null);
        int count = cursor.getCount();
        db.close();
        cursor.close();

        return count;
    }

    public int updateContact(app.com.nishswag.android.lawyers1002.Contact contact) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PHONE, contact.getPhone());
        values.put(KEY_EMAIL, contact.getEmail());
        values.put(KEY_ADDRESS, contact.getAddress());
        values.put(KEY_IMAGEURI, contact.getImageURI().toString());

        int rowsAffected = db.update(TABLE_CONTACTS, values, KEY_ID + "=?", new String[] { String.valueOf(contact.getId()) });
        db.close();

        return rowsAffected;
    }

    public List<Contact> getAllContacts() {
        List<app.com.nishswag.android.lawyers1002.Contact> contacts = new ArrayList<app.com.nishswag.android.lawyers1002.Contact>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CONTACTS, null);

        if (cursor.moveToFirst()) {
            do {
                contacts.add(new app.com.nishswag.android.lawyers1002.Contact(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), Uri.parse(cursor.getString(5))));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return contacts;
    }

    public List<Cases> getAllCases() {
        List<Cases> cases = new ArrayList<Cases>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CASES, null);

        if (cursor.moveToFirst()) {
            do {
                cases.add(new Cases(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7), cursor.getString(8)));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return cases;
    }

    public List<String> getAllLabels(){
        List<String> cases = new ArrayList<String>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_CASES;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                cases.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }

        // closing connection
        cursor.close();
        db.close();

        // returning lables
        return cases;
    }



}
