package app.com.nishswag.android.lawyers1002;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Casing extends MainActivity {

    private static final int EDIT = 0, DELETE = 1;

    EditText casenumberTxt, casestartTxt, caseendTxt, casepetTxt, caserespTxt, casecourtTxt, casestateTxt, casenotesTxt;
    List<Cases> Casei = new ArrayList<Cases>();
    ListView casesListView;
    DatabaseHandler dbHandler;
    int longClickedItemIndex;
    ArrayAdapter<Cases> casesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cases_activity);

        casenumberTxt = (EditText) findViewById(R.id.txtCaseNumber);
        casestartTxt = (EditText) findViewById(R.id.txtCaseStart);
        caseendTxt = (EditText) findViewById(R.id.txtCaseEnd);
        casepetTxt = (EditText) findViewById(R.id.txtCasePet);
        caserespTxt = (EditText) findViewById(R.id.txtCaseResp);
        casecourtTxt = (EditText) findViewById(R.id.txtCaseCourt);
        casestateTxt = (EditText) findViewById(R.id.txtCaseState);
        casenotesTxt = (EditText) findViewById(R.id.txtCaseNotes);
        casesListView = (ListView) findViewById(R.id.listView);
        dbHandler = new DatabaseHandler(getApplicationContext());

        registerForContextMenu(casesListView);

        casesListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                longClickedItemIndex = position;
                return false;
            }
        });

        TabHost tabHost2 = (TabHost) findViewById(R.id.tabHost2);

        tabHost2.setup();

        TabHost.TabSpec tabSpec = tabHost2.newTabSpec("Add New Case");
        tabSpec.setContent(R.id.tabCase);
        tabSpec.setIndicator("Add New Case");
        tabHost2.addTab(tabSpec);

        tabSpec = tabHost2.newTabSpec("List Cases");
        tabSpec.setContent(R.id.tabCaseList);
        tabSpec.setIndicator("List Cases");
        tabHost2.addTab(tabSpec);

        final Button addcaseBtn = (Button) findViewById(R.id.btnAddCase);
        addcaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cases cases = new Cases(dbHandler.getCasesCount(), String.valueOf(casenumberTxt.getText()), String.valueOf(casestartTxt.getText()), String.valueOf(caseendTxt.getText()), String.valueOf(casepetTxt.getText()), String.valueOf(caserespTxt.getText()), String.valueOf(casecourtTxt.getText()), String.valueOf(casestateTxt.getText()), String.valueOf(casenotesTxt.getText()));
                if (!casesExists(cases)) {
                    dbHandler.createCases(cases);
                    Casei.add(cases);
                    casesAdapter.notifyDataSetChanged();
                    Toast.makeText(getApplicationContext(), String.valueOf(casenumberTxt.getText()) + " has been added to your Contacts!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(getApplicationContext(), String.valueOf(casenumberTxt.getText()) + " already exists. Please use a different name.", Toast.LENGTH_SHORT).show();
            }
        });


        casenumberTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                addcaseBtn.setEnabled(String.valueOf(casenumberTxt.getText()).trim().length() > 0);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if (dbHandler.getCasesCount() != 0)
            Casei.addAll(dbHandler.getAllCases());

        populateList();
    }

    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, view, menuInfo);

        menu.setHeaderIcon(R.drawable.pencil_icon);
        menu.setHeaderTitle("Case Options");
        menu.add(Menu.NONE, EDIT, menu.NONE, "Edit Case");
        menu.add(Menu.NONE, DELETE, menu.NONE, "Delete Case");
    }

    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case EDIT:
                // TODO: Implement editing a case
                break;
            case DELETE:
                dbHandler.deleteCases(Casei.get(longClickedItemIndex));
                Casei.remove(longClickedItemIndex);
                casesAdapter.notifyDataSetChanged();
                break;
        }

        return super.onContextItemSelected(item);
    }
        private boolean casesExists(Cases cases) {
            String name = cases.getCaseNumber();
            int casesCount = Casei.size();

            for (int i = 0; i < casesCount; i++) {
                if (name.compareToIgnoreCase(Casei.get(i).getCaseNumber()) == 0)
                    return true;
            }
            return false;
        }
    private void populateList() {
        casesAdapter = new CasesListAdapter();
        casesListView.setAdapter(casesAdapter);
    }

    private class CasesListAdapter extends ArrayAdapter<Cases> {
        public CasesListAdapter() {
            super (Casing.this, R.layout.listview_item2, Casei);
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {
            if (view == null)
                view = getLayoutInflater().inflate(R.layout.listview_item2, parent, false);

            Cases currentCases = Casei.get(position);

            TextView numberCase = (TextView) view.findViewById(R.id.caseNumber);
            numberCase.setText(currentCases.getCaseNumber());

            TextView petitionerCase = (TextView) view.findViewById(R.id.casePetitioner);
            petitionerCase.setText(currentCases.getPetitioners());

            TextView respondantCase = (TextView) view.findViewById(R.id.caseRespondant);
            respondantCase.setText(currentCases.getRespondants());

            TextView startdateCase = (TextView) view.findViewById(R.id.caseStartDate);
            startdateCase.setText(currentCases.getStartDate());

            TextView enddateCase = (TextView) view.findViewById(R.id.caseEndDate);
            enddateCase.setText(currentCases.getEndDate());

            TextView nameCourt = (TextView) view.findViewById(R.id.courtName);
            nameCourt.setText(currentCases.getCourtName());

            TextView stateCourt = (TextView) view.findViewById(R.id.courtState);
            stateCourt.setText(currentCases.getCourtState());

            TextView notesCase = (TextView) view.findViewById(R.id.caseNotes);
            notesCase.setText(currentCases.getCaseNotes());


            return view;
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


}
